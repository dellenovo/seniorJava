package com.lifei.mongohac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongohacApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongohacApplication.class, args);
	}

}
