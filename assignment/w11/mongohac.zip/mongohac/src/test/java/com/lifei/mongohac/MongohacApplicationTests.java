package com.lifei.mongohac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongohacApplicationTests {

	@Test
	void contextLoads() {
	}

}
